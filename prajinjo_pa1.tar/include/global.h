#ifndef GLOBAL_H_
#define GLOBAL_H_

#define HOSTNAME_LEN 128
#define PATH_LEN 256
#define BUF_SIZE 300
#define BROADCAST_IP "255.255.255.255"

#define MAX_CLIENTS 4

#define STDIN 0  
#endif
